#ifndef TAXFUNCTIONS_H_
#define TAXFUNCTIONS_H_

float CalcHST( float price );
float CalcGHT( float price );
float CalcHSTNefoundland( float price );

#endif /*TAXFUNCTIONS_H_*/

