#ifndef CTAXFUNCTIONS_H_
#define CTAXFUNCTIONS_H_

//cTaxFunctions.h

class cTaxFunctions
{
public:
	float CalcHST( float price );	
	float CalcGHT( float price );
	float CalcHSTNefoundland( float price );
	
};

#endif /*CTAXFUNCTIONS_H_*/
